﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using WindowsFormsApp1__پروژه_نهایی_;


namespace WindowsFormsApp1__پروژه_نهایی_
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        Dictionary<string, Student> students = new Dictionary<string, Student>();
        string filePath = @"C:\202\std.txt";

        private void LoadStudents()
        {
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                students.Clear();
                listBox1.Items.Clear();

                foreach (string line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 4)
                    {
                        Student s = new Student
                        {
                            StdNum = parts[0],
                            StdName = parts[1],
                            StdFamily = parts[2],
                            Course = parts[3]
                        };
                        students[s.StdNum] = s;
                        listBox1.Items.Add($"{s.StdNum} - {s.StdName} {s.StdFamily}");
                    }
                }
            }
        }

        private void SaveStudents()
        {
            List<string> lines = new List<string>();
            foreach (var s in students.Values)
            {
                lines.Add($"{s.StdNum},{s.StdName},{s.StdFamily},{s.Course}");
            }
            File.WriteAllLines(filePath, lines);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string num = txtNum.Text;
            if (!students.ContainsKey(num))
            {
                Student s = new Student
                {
                    StdNum = num, 
                    StdName = txtName.Text,
                    StdFamily = txtFamily.Text,
                    Course = txtCourse.Text
                };
                students[num] = s;
                SaveStudents();
                LoadStudents();
                MessageBox.Show("دانشجو اضافه شد.");
                txtCourse.Clear();
                txtFamily.Clear();
                txtName.Clear();
                txtNum.Clear();
            }
            else
            {
                MessageBox.Show("شماره دانشجویی تکراری است.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string num = txtNum.Text;
            if (students.ContainsKey(num))
            {
                students.Remove(num);
                SaveStudents();
                LoadStudents();
                MessageBox.Show("دانشجو حذف شد.");
            }
            else
            {
                MessageBox.Show("دانشجو پیدا نشد.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string num = txtNum.Text;
            if (students.ContainsKey(num))
            {
                students[num].StdName = txtName.Text; 
                students[num].StdFamily = txtFamily.Text;
                students[num].Course = txtCourse.Text;

                SaveStudents();
                LoadStudents();
                MessageBox.Show("اطلاعات دانشجو به‌روز شد.");

            }
            else
            {
                MessageBox.Show("دانشجو پیدا نشد.");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
