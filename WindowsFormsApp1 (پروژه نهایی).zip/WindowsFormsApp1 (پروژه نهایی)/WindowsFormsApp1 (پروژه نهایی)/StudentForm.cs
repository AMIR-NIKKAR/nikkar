﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using WindowsFormsApp1__پروژه_نهایی_;


namespace WindowsFormsApp1__پروژه_نهایی_
{

    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string num = txtnnum.Text;
            string path = @"C:\202\std.txt";

            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    var parts = line.Split(',');
                    if (parts[0] == num)
                    {
                        txtName.Text = parts[1];
                        txtFamily.Text = parts[2];
                        txtccourse.Text = parts[3];
                        return;
                    }
                }

                MessageBox.Show("دانشجو پیدا نشد.");
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            string num = txtnnum.Text;
            string path = @"C:\202\std.txt";

            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                for (int i = 0; i < lines.Length; i++)
                {
                    var parts = lines[i].Split(',');
                    if (parts[0] == num)
                    {
                        parts[3] = txtccourse.Text;
                        lines[i] = string.Join(",", parts);
                        File.WriteAllLines(path, lines);
                        MessageBox.Show("درس‌ها ذخیره شد.");
                        return;
                    }
                }
                
                MessageBox.Show("دانشجو پیدا نشد.");
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
