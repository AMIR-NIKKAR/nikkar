﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1__پروژه_نهایی_
{
   
        public class Student
        {
            public string StdNum { get; set; }
            public string StdName { get; set; }
            public string StdFamily { get; set; }
            public string Course { get; set; }
        }

}
